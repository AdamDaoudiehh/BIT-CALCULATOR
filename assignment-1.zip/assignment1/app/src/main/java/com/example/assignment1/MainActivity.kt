package com.example.assignment1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.*
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.View




class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)



        //layout vars
        val button: Button = findViewById(R.id.button)
        val input: EditText = findViewById(R.id.input)
        val result: TextView = findViewById(R.id.result)
        var y:  String = "0";

        val spinner : Spinner = findViewById(R.id.op)
        var options = arrayOf("binary to decimal","decimal to binary")
        spinner.adapter = ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,options )


        button.setOnClickListener { view ->
            val x = input.text.toString().toInt();

            if(y =="decimal to binary"){
                val r: String = Integer.toBinaryString(x)
                    result.text = r.toString();
            }
            if(y =="binary to decimal"){

                val r = convertBinaryToDecimal(x.toLong())
                result.text = r.toString();
            }

        }

        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener{
            override fun onItemSelected(p0: AdapterView<*>?, p1: View?, p2: Int, p3: Long) {
                y = options[p2].toString() //p2 is the index of selected item
            }
            override fun onNothingSelected(p0: AdapterView<*>?) {
                TODO("Not yet implemented")
            }


        }

    }
} fun convertBinaryToDecimal(num: Long): Int {
    var num = num
    var decimalNumber = 0
    var i = 0
    var remainder: Long

    while (num.toInt() != 0) {
        remainder = num % 10
        num /= 10
        decimalNumber += (remainder * Math.pow(2.0, i.toDouble())).toInt()
        ++i
    }
    return decimalNumber
}